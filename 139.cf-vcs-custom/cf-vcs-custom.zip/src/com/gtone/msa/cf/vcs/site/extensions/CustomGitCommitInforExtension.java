package com.gtone.msa.cf.vcs.site.extensions;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import org.hibernate.validator.internal.util.StringHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.gtone.msa.cf.vcs.db.CacheResultSet;
import com.gtone.msa.cf.vcs.db.CommonDAO;
import com.gtone.msa.cf.vcs.extensions.defaults.DefaultGitCommitInfoExtension;
import com.gtone.msa.cf.vcs.vcs.IVCSConst;

/**
 * 용도 : git outsynker commit시 커밋 정보를 사이트에서 커스텀 할 수 있도록 확장
 * 코딩 가이드:
 * DefaultGitCommitInfoExtension 을 상속를 상속 받아야 합니다.
 * annotation 가이드
 * 	@Component : 컴포넌트로 인식
 *  @Primary : 우선순위 설정 (본사 기본 모듈을 무시하게 설정하기 위해 필수)
 */
@Component
@Primary
public class CustomGitCommitInforExtension extends DefaultGitCommitInfoExtension {
	private static final Logger logger = LoggerFactory.getLogger(CustomGitCommitInforExtension.class);
	
	 public Object getCommitInfo(Map<BigDecimal, List<HashMap>> sortedMap, Map<String, Object> scheduleParamMap) throws Exception {
    	// DB 연결시 필요하면 아래 소스 참고
    	CommonDAO dao = new CommonDAO();
    	CacheResultSet crs = dao.executeQuery("vcs_site.findRequest", new HashMap());
    	if(crs.next())
    	{
    		logger.info(crs.getMap().toString());
    		logger.info("ojjamkj success");
    	}
    	dao.close();
    	
    	//넘어온 파라미터 안에 있는 정보로 commit 정보를 만들려면 아래 소스 참고
        ArrayList commentList = new ArrayList();
        AtomicReference<String> presentativeAuthor = new AtomicReference<>(null);
        AtomicReference<String> author = new AtomicReference<>("");

        sortedMap.forEach((workTime, resList) -> {

            resList.forEach((map) -> {

                if (map.get(IVCSConst.SITE_DOC_NO) != null && map.get(IVCSConst.CHANGE_TITLE) != null) {
                    String comment = "[" + map.get(IVCSConst.SITE_DOC_NO) + "] " + map.get(IVCSConst.CHANGE_TITLE) + " - " + map.get(IVCSConst.COMMIT_AUTHOR);
                    if (!commentList.contains(comment)) {
                        commentList.add(comment);
                    }
                }

                author.set((String) map.get(IVCSConst.COMMIT_AUTHOR));


                if (presentativeAuthor.get() == null) {
                    presentativeAuthor.set(author.get());
                }
            });
        });

        commentList.add(0, "Sync from ChangeFlow\n");
        String finalComment = StringHelper.join(commentList, "\n");

        HashMap commentInfoMap = new HashMap();
        commentInfoMap.put(IVCSConst.COMMIT_COMMITTER, presentativeAuthor.get());
        commentInfoMap.put(IVCSConst.COMMIT_COMMENT, finalComment);

        return commentInfoMap;

    }
    
    @Override
    public String getName() throws Exception {
    	return "customCommitInfoExtension";
    }
}